/* packet-ess.h
 * Routines for RFC5035 Extended Security Services packet dissection
 *    Ronnie Sahlberg 2004
 *    Stig Bjorlykke 2010
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef PACKET_ESS_H
#define PACKET_ESS_H

#include "packet-ess-exp.h"

#endif  /* PACKET_ESS_H */

