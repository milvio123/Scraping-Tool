/* packet-logotypecertextn.h
 * Routines for RFC3907 Logotype Certificate Extensions packet dissection
 *    Ronnie Sahlberg 2004
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef PACKET_LOGOTYPE_CERT_EXTN_H
#define PACKET_LOGOTYPE_CERT_EXTN_H

/*#include "packet-logotypecertextn-exp.h"*/

#endif  /* PACKET_LOGOTYPE_CERT_EXTN_H */

