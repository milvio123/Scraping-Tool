/* kasumi.h
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef	KASUMI_H
#define	KASUMI_H

/*This needs to be set in order to indicate presence of KASUMI implementation!*/
/*#define HAVE_UMTS_KASUMI*/


#endif /* KASUMI_H */
